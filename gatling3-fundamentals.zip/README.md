Gatling 3 Fundamentals
=========================

Course code for the Gatling Fundamentals Udemy course - updated for Gatling v3

https://www.udemy.com/gatling-fundamentals



OctoPerf article
=========================
https://octoperf.com/blog/2020/03/05/kraken-gatling-getting-started-with-simulation-scripts/
https://octoperf.com/blog/2020/03/14/kraken-gatling-simulation-script-parameterization/
https://octoperf.com/blog/2020/05/07/kraken-gatling-loops-conditions-pauses-think-times
https://octoperf.com/blog/2020/08/18/kraken-gatling-post-forms-modular-scripts

